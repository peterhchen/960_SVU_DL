# If this script doesn't work, just manually zip together your Jupter notebooks,
rm assignment4.zip
# the deeprl folder, and the logs folder. 
zip -r assignment4.zip *.ipynb deeprl logs
